import { motion, useReducedMotion } from 'framer-motion';
import { ImageIcon, Tent } from 'lucide-react';
import type { ReactNode } from 'react';
import type { CaseStudy } from '@/data/caseStudies';

export function CaseLogo({ study }: { study: CaseStudy }) {
  return <div className={`case-logo${study.logo ? '' : ' case-logo-icon'}${study.logoOnDark ? ' case-logo-dark' : ''}`}>
    {study.logo ? <img src={study.logo} alt={`${study.client} logo`} loading="lazy" width="180" height="70" /> : <Tent aria-label="Youth camp" size={30} strokeWidth={1.3} />}
  </div>;
}

export function CaseTitle({ title }: { title: string }) {
  const words = title.split(' ');
  return <>{words.slice(0, -1).join(' ')} <em>{words.at(-1)}</em></>;
}

export function DetailsPending() { return <div className="details-pending">Details coming soon</div>; }
export function ScreenshotPending() { return <div className="screenshot-pending"><ImageIcon aria-hidden="true" size={26} strokeWidth={1} /><span>Screenshot coming soon</span></div>; }

export function CaseReveal({ children, className = '', index = 0 }: { children: ReactNode; className?: string; index?: number }) {
  const reduced = useReducedMotion();
  return <motion.div className={className} initial={reduced ? false : { opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.08 }} transition={{ duration: reduced ? 0 : 0.4, delay: reduced ? 0 : index * 0.06, ease: 'easeOut' }}>{children}</motion.div>;
}