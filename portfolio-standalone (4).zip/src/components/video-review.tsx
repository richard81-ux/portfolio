import { useState } from 'react';

export type VideoReviewData = {
  id: string; name: string; role: string;
  headline?: [string, string]; pullQuote?: string; transcript?: string;
};

export function VideoReview({ video, caption = true }: { video: VideoReviewData; caption?: boolean }) {
  const [playing, setPlaying] = useState(false);
  return (
    <figure className="video-review">
      <div className="video-frame">
        {playing ? (
          <iframe
            src={`https://www.youtube-nocookie.com/embed/${video.id}?autoplay=1&playsinline=1&rel=0&modestbranding=1&cc_load_policy=1`}
            title={`Video review from ${video.name}, ${video.role}`}
            allow="accelerometer; autoplay; encrypted-media; picture-in-picture; fullscreen"
            allowFullScreen
            referrerPolicy="strict-origin-when-cross-origin"
          />
        ) : (
          <button type="button" className="video-poster" onClick={() => setPlaying(true)} aria-label={`Play video review from ${video.name}, ${video.role}`}>
            <img src={`https://i.ytimg.com/vi/${video.id}/hqdefault.jpg`} alt="" loading="lazy" decoding="async" onError={e => { e.currentTarget.style.display = 'none'; }} />
            <span className="video-play" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M8 5.5v13a1 1 0 0 0 1.5.86l10.6-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5z" /></svg></span>
          </button>
        )}
      </div>
      {caption && <figcaption><strong>{video.name}</strong><span>{video.role}</span></figcaption>}
    </figure>
  );
}

export function ClientFeature({ video, link }: { video: VideoReviewData; link?: boolean }) {
  return (
    <div className="client-feature-body">
      <VideoReview video={video} caption={false} />
      <div className="client-feature-quote">
        <span className="client-quote-mark" aria-hidden="true">&ldquo;</span>
        <blockquote>{video.pullQuote}</blockquote>
        <div className="client-person"><strong>{video.name}</strong><span>{video.role}</span></div>
        {video.transcript && (
          <details className="client-transcript">
            <summary>Read the full video</summary>
            <p>{video.transcript}</p>
          </details>
        )}
        {link && <a className="text-link" href="/work/kimball-studio">Read the Kimball Studio case study &rarr;</a>}
      </div>
    </div>
  );
}
