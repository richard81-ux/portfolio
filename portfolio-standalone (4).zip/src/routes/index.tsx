import { ClientFeature } from '@/components/video-review';
import { kimballVideo } from '@/data/caseStudies';
import { createFileRoute } from '@tanstack/react-router';
import { useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowUpRight, BadgeCheck, ChevronRight, Database, Layers3, Menu, ShieldCheck, Sparkles, Star, Workflow, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { CaseStudyList } from '@/components/case-study-list';
import { CostCalculator } from '@/components/cost-calculator';
import { bookingUrl, type BookingPlace } from '@/lib/booking';
import portrait from '@/assets/anayo-richard.png.asset.json';
import softr from '@/assets/softr-partner.png.asset.json';
import kimball from '@/assets/kimball-studio.png.asset.json';
import serrani from '@/assets/serrani-properties.png.asset.json';
import orbi from '@/assets/orbi-logo.png.asset.json';
import emeritus from '@/assets/emeritus.png.asset.json';
import makeAdvanced from '@/assets/make-advanced.png.asset.json';
import aiExplorer from '@/assets/ai-automation-explorer.png.asset.json';
import softrCert from '@/assets/softr-professional-certificate.png.asset.json';
import topRated from '@/assets/top-rated.png.asset.json';
import jobSuccess from '@/assets/job-success.png.asset.json';
import whatsappTile from '@/assets/whatsapp-tile.png.asset.json';
import whatsappLight from '@/assets/whatsapp-light.png.asset.json';
import whatsappAccent from '@/assets/whatsapp-accent.png.asset.json';
import upworkLight from '@/assets/upwork-light.png.asset.json';
import upworkAccent from '@/assets/upwork-accent.png.asset.json';
import softrAccent from '@/assets/softr-accent.png.asset.json';
import softrPalette from '@/assets/softr-palette.png.asset.json';

const softrLight = { url: '/icons/softr-light.png' };
const gmailTile = { url: '/icons/gmail-tile.png' };
const gmailLight = { url: '/icons/gmail-light.png' };
const gmailAccent = { url: '/icons/gmail-accent.png' };
const linkedinLight = { url: '/icons/linkedin-light.png' };
const linkedinAccent = { url: '/icons/linkedin-accent.png' };
const upwork = 'https://www.upwork.com/freelancers/~01a9c1174fb11bd21d';
const email = 'mailto:anayorichard81@gmail.com';
const linkedin = 'https://www.linkedin.com/in/anayo-richard/';
const whatsapp = 'https://wa.me/2349153274297';
const softrPartner = 'https://www.softr.io/partners/anayo-richard';
const softrReferral = 'https://get.softr.io/xi45icy64zfg';
const nav = ['Work', 'Services', 'Credentials', 'Process', 'Contact'];
const description = 'Softr Certified Partner and Airtable expert building client portals and automations that take repeat work off your team. Book a free 30 minute call with Anayo Richard.';
const title = 'Softr Developer and Airtable Expert | Client Portals and Automation | Anayo Richard';
export const Route = createFileRoute('/')({
  component: Portfolio,
  head: () => ({
    meta: [
      { title },
      { name: 'description', content: description },
      { property: 'og:title', content: title },
      { property: 'og:description', content: description },
      { property: 'og:type', content: 'website' },
      { property: 'og:url', content: '/' },
      { name: 'twitter:card', content: 'summary_large_image' },
    ],
  }),
});
const projects = [
  { name: 'Kimball Studio', logo: kimball.url, previewTitle: ['Member', 'portal'], type: 'Member portal & website', description: 'Member portal for an acting school, and now a new website build connected to Airtable forms.', tags: ['Softr', 'Airtable', 'Wix'] },
  { name: 'Emeritus Clinical Solutions', logo: emeritus.url, previewTitle: ['Equipment', 'tracker'], type: 'Equipment tracking & integration', description: 'Equipment tracking app for biomedical equipment with an automated sync to SharePoint.', tags: ['Softr', 'Airtable', 'Make.com'] },
  { name: 'Orbi Learning', logo: orbi.url, previewTitle: ['Tutoring', 'platform'], type: 'Tutoring platform & workflows', description: 'Tutoring platform with automated workflows.', tags: ['Glide', 'Make.com'] },
  { name: 'Serrani Properties', logo: serrani.url, previewTitle: ['Tenant payment', 'portal'], type: 'Tenant portal & payment automation', description: 'Tenant payment portal with an automated payment ledger engine.', tags: ['Wix', 'Make.com', 'Python', 'Google Cloud Console'] },
];
const brands = projects.slice().sort((a, b) => ['Kimball Studio', 'Serrani Properties', 'Orbi Learning', 'Emeritus Clinical Solutions'].indexOf(a.name) - ['Kimball Studio', 'Serrani Properties', 'Orbi Learning', 'Emeritus Clinical Solutions'].indexOf(b.name));
const services = [
  { icon: Layers3, title: 'Client and member portals', copy: 'Softr + Airtable: secure logins, role-based access, dashboards and private document sections.' },
  { icon: Database, title: 'Airtable systems and websites', copy: 'Clean data architecture that grows with your business, plus Wix websites connected to Airtable forms and databases.' },
  { icon: Workflow, title: 'Automation and integrations', copy: 'Make.com workflows, Stripe payments, GoHighLevel, Python scripts and API connections that remove manual work.' },
  { icon: Sparkles, title: 'AI-assisted workflows', copy: 'LLM-powered steps added to your processes, like document intake and AI assistants inside your app.' },
];
const steps = [
  ['Understand', 'Map how your team works.'],
  ['Design', 'Data model and user journeys.'],
  ['Build', 'Working features with regular demos.'],
  ['Hand over', 'Documentation and support so you can run it yourself.'],
];
const stack = ['Softr', 'Airtable', 'Make.com', 'Wix', 'GoHighLevel', 'Glide', 'Stripe', 'Python', 'OpenAI and Claude APIs'];
function BookButton({ place, compact = false, label }: { place: BookingPlace; compact?: boolean; label?: string }) {
  return <Button asChild variant="portfolio" size={compact ? 'default' : 'portfolio'}><a href={bookingUrl(place)} target="_blank" rel="noopener noreferrer">{label ?? (compact ? 'Book a free call' : 'Book a free 30 min call')} <ArrowUpRight /></a></Button>;
}
const pains = ['Your team copies the same data into three places.', 'Clients keep asking you for updates.', 'Your tools do not talk to each other.'];
const callSteps = ['You pick a time.', 'We talk for 30 minutes about the process you want to fix.', 'You leave with a clear next step: what to build first, roughly how long it takes, and what I need from you.'];
const faqs = [
  ['How do I know you will deliver?', 'You see working features in regular demos, we agree the scope before I start, and my Upwork record is public, with a 100% Job Success score.'],
  ['What does it cost?', 'It depends on what you need. After the call I will send a clear scope and price before any work starts.'],
  ['Do I need to be technical?', 'No. I explain things in plain language and hand over simple documentation.'],
  ['What tools do you work with?', 'Softr, Airtable, Make, Wix and GoHighLevel, plus APIs when needed.'],
  ['Can I pay through Upwork?', 'Yes. If you like, we can set up the project on Upwork for payment protection.'],
  ['What if I am not sure what I need?', 'That is what the call is for. Bring the problem, not the solution.'],
];
function WhatsAppButton() {
  return <Button asChild variant="portfolioOutline" size="portfolio"><a href={whatsapp} target="_blank" rel="noopener noreferrer"><img className="btn-icon" src={whatsappTile.url} alt="" width={18} height={18} /><span><span className="wa-prefix">Chat on </span>WhatsApp</span></a></Button>;
}
function EmailButton() {
  return <Button asChild variant="portfolioOutline" size="portfolio"><a href={email}><img className="btn-icon" src={gmailTile.url} alt="" width={18} height={18} />Email me</a></Button>;
}
function LinkIcon({ light, accent }: { light: string; accent: string }) {
  return <span className="contact-link-icon" aria-hidden="true"><img className="icon-default" src={light} alt="" width={14} height={14} /><img className="icon-hover" src={accent} alt="" width={14} height={14} /></span>;
}
function Wordmark() {
  return <a className="wordmark" href="#top" aria-label="Anayo Richard, back to top">Anayo Richard<span className="text-primary">.</span></a>;
}
function SectionHeading({ label, children, number }: { label: string; children: React.ReactNode; number: string }) {
  return <div className="section-heading"><div><div className="eyebrow">{label}</div><h2>{children}</h2></div><span className="section-index">{number} / ANAYO RICHARD</span></div>;
}
function Portfolio() {
  const [menuOpen, setMenuOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.add('is-visible'); observer.unobserve(entry.target); }
    }), { threshold: 0.08 });
    rootRef.current?.querySelectorAll('.reveal').forEach(el => observer.observe(el));
    return () => observer.disconnect();
  }, []);
  return <div ref={rootRef} id="top">
    <header className="site-header">
      <div className="wrap nav-row"><Wordmark /><nav className="desktop-nav" aria-label="Main navigation">{nav.map(item => <a key={item} href={`#${item.toLowerCase()}`}>{item}</a>)}</nav><div className="nav-cta"><BookButton place="nav" compact /></div><Button className="menu-trigger" variant="ghost" size="icon" aria-label={menuOpen ? 'Close navigation' : 'Open navigation'} aria-expanded={menuOpen} aria-controls="mobile-navigation" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</Button></div>
      {menuOpen && <nav id="mobile-navigation" className="wrap mobile-nav" aria-label="Mobile navigation">{nav.map(item => <a onClick={() => setMenuOpen(false)} key={item} href={`#${item.toLowerCase()}`}>{item}</a>)}<a className="mobile-hire" href={bookingUrl('nav')} target="_blank" rel="noopener noreferrer">Book a free call ↗</a></nav>}
    </header>
    <main>
      <section className="hero wrap" aria-labelledby="hero-title">
        <div className="hero-grid"><div className="hero-copy"><div className="eyebrow">Softr Certified Partner · Make.com Advanced</div><h1 id="hero-title">Stop running your business on <em>spreadsheets and email.</em></h1><p className="hero-description">I build client portals and automations that take repeat work off your team. I am a Softr Certified Partner, and I work with Airtable and Make.</p><div className="hero-actions"><BookButton place="hero" /><div className="action-pair"><Button asChild variant="portfolioOutline" size="portfolio"><a href="#work">See my work <ArrowDown /></a></Button><WhatsAppButton /></div></div><p className="cta-note">Free. No obligation. You leave with a clear next step.</p></div>
          <div className="portrait-area"><div className="portrait-frame"><img src={portrait.url} alt="Anayo Richard, freelance no-code developer" fetchPriority="high" /></div><a className="portrait-badge" href={softrPartner} target="_blank" rel="noopener noreferrer"><img src={softr.url} alt="Softr Certified Partner badge" /><span className="partner-profile-label">View my partner profile ↗</span></a><a className="upwork-chip" href={upwork} target="_blank" rel="noopener noreferrer"><img src={topRated.url} alt="" width={14} height={14} />Top Rated on Upwork</a></div></div>
        <div className="trust-row"><span><ShieldCheck />Softr Certified Partner</span><a href={upwork} target="_blank" rel="noopener noreferrer"><img src={topRated.url} alt="" width={14} height={14} />Top Rated on Upwork</a><a href={upwork} target="_blank" rel="noopener noreferrer"><img src={jobSuccess.url} alt="" width={14} height={14} />100% Job Success</a></div>
      </section>
      <section className="brands wrap" aria-label="Client brands"><div className="eyebrow">Brands I've built for</div><div className="marquee"><div className="marquee-track">{[0, 1].map(set => <div className="flex gap-4" key={set} aria-hidden={set === 1 ? true : undefined}>{brands.map(brand => <div className="logo-tile" key={brand.name}>{brand.logo ? <img src={brand.logo} alt={`${brand.name} logo`} /> : <span className="missing-logo">[ORBI LOGO]</span>}</div>)}</div>)}</div></div></section>
      <section className="section pains-section" aria-labelledby="pains-title"><div className="wrap reveal"><div className="section-heading"><div><div className="eyebrow">The everyday friction</div><h2 id="pains-title">Sound <em>familiar?</em></h2></div></div><div className="pain-grid">{pains.map(p => <article className="pain-card" key={p}><p>{p}</p></article>)}</div></div></section>
      <CaseStudyList />
      <CostCalculator />
      <section id="services" className="section services-band"><div className="wrap reveal"><SectionHeading label="Less admin. More possibility." number="02">What I <em>build</em></SectionHeading><div className="service-grid">{services.map(service => <article className="service-card" key={service.title}><service.icon className="service-icon" /><h3>{service.title}</h3><p>{service.copy}</p></article>)}</div></div></section>
      <section id="credentials" className="section"><div className="wrap reveal"><SectionHeading label="The tools, understood deeply" number="03">Certified where it <em>counts</em></SectionHeading><div className="credential-grid"><a className="credential-item credential-partner" href={softrPartner} target="_blank" rel="noopener noreferrer"><div className="credential-image"><img src={softr.url} alt="Softr Certified Partner badge" loading="lazy" /></div><h3>Softr Certified Partner ↗</h3><p>Softr</p><span className="credential-cta">View partner profile ↗</span></a><article className="credential-item"><div className="credential-image"><img src={makeAdvanced.url} alt="Make Academy Advanced certification badge" loading="lazy" /></div><h3>Make Advanced</h3><p>Make Academy</p></article><article className="credential-item"><div className="credential-image"><img src={aiExplorer.url} alt="Make Academy AI Automation Explorer badge" loading="lazy" /></div><h3>Make AI Automation Explorer</h3><p>Make Academy</p></article><article className="credential-item"><div className="credential-image cert-thumb"><img src={softrCert.url} alt="Softr Professional Certification presented to Anayo Richard" loading="lazy" /></div><h3>Softr Professional Developer</h3><p>Softr</p></article></div><article className="upwork-card"><div><h3>See my reviews on Upwork.</h3><p>Top Rated, 100% Job Success.</p></div><a className="text-link" href={upwork} target="_blank" rel="noopener noreferrer">View my Upwork profile <ArrowUpRight /></a></article></div></section>
      <section id="process" className="section process-section"><div className="wrap reveal"><SectionHeading label="Clear from the first conversation" number="04">How we <em>work</em></SectionHeading><div className="process-grid">{steps.map(([title, copy], index) => <article className="process-step" key={title}><span className="step-num">0{index + 1}</span><h3>{title}</h3><p>{copy}</p></article>)}</div></div></section>
      <section id="call" className="section" aria-labelledby="call-title"><div className="wrap reveal"><div className="section-heading"><div><div className="eyebrow">30 minutes, free</div><h2 id="call-title">What happens on the <em>call</em></h2></div></div><ol className="call-steps">{callSteps.map((s, i) => <li key={s}><span className="step-num">{i + 1}.</span><p>{s}</p></li>)}</ol><p className="cta-note">No pitch. No obligation.</p><div className="hero-actions section-cta"><BookButton place="call-steps" /></div></div></section>
      <div className="wrap stack" aria-label="Technology stack"><span className="stack-label">MY STACK</span><div className="tags">{stack.map(item => <span className="tag" key={item}>{item}</span>)}</div></div>
      <section className="testimonial-section wrap reveal" aria-label="Client testimonials"><div className="client-feature"><div className="eyebrow">What a client said</div><h2 className="client-feature-title">&ldquo;{kimballVideo.headline?.[0]} <em>{kimballVideo.headline?.[1]}</em>&rdquo;</h2><ClientFeature video={kimballVideo} link /></div><figure className="quote-card"><span className="quote-symbol" aria-hidden="true">“</span><div><blockquote>“Anayo delivered exactly what I needed. Built my Airtable database and Softr portal cleanly and faster than expected. Automations work perfectly and he explained everything before handing over. Will hire again.”</blockquote><figcaption><div><strong>Upwork client, 5.0 rating</strong><p>Fix My Airtable Base &amp; Set Up a Simple Softr Portal</p></div><span className="rating" aria-label="5 out of 5 stars">{Array.from({ length: 5 }, (_, i) => <Star key={i} aria-hidden="true" />)}</span></figcaption></div></figure></section>
      <section id="faq" className="section" aria-labelledby="faq-title"><div className="wrap reveal"><div className="section-heading"><div><div className="eyebrow">Straight answers</div><h2 id="faq-title">Common <em>questions</em></h2></div></div><div className="faq-list">{faqs.map(([q, a]) => <details className="faq-item" key={q}><summary>{q}<ChevronRight aria-hidden="true" /></summary><p>{a}</p></details>)}</div><div className="hero-actions section-cta"><BookButton place="faq" /></div></div></section>
      <section id="contact" className="contact-section"><div className="wrap contact-layout reveal"><div><div className="eyebrow">Let's make it work</div><h2>Have a system<br />to <em>build?</em></h2></div><div className="contact-links"><div className="hero-actions"><BookButton place="closing" /><div className="action-pair"><EmailButton /><WhatsAppButton /></div></div><a className="text-link" href={linkedin} target="_blank" rel="noopener noreferrer"><LinkIcon light={linkedinLight.url} accent={linkedinAccent.url} />Connect on LinkedIn <ArrowUpRight /></a><a className="text-link" href={softrReferral} target="_blank" rel="noopener noreferrer"><img className="small-link-icon" src={softrPalette.url} alt="" width={14} height={14} />Prefer to build it yourself? Try Softr ↗</a></div></div></section>
    </main>
    <footer className="footer wrap"><div className="footer-row"><Wordmark /><div className="footer-links"><a className="text-link" href={email}><LinkIcon light={gmailLight.url} accent={gmailAccent.url} />anayorichard81@gmail.com</a><a className="text-link" href={upwork} target="_blank" rel="noopener noreferrer"><LinkIcon light={upworkLight.url} accent={upworkAccent.url} />Upwork <ArrowUpRight /></a><a className="text-link" href={whatsapp} target="_blank" rel="noopener noreferrer"><LinkIcon light={whatsappLight.url} accent={whatsappAccent.url} />WhatsApp</a><a className="text-link" href={softrPartner} target="_blank" rel="noopener noreferrer"><LinkIcon light={softrLight.url} accent={softrAccent.url} />Softr Partner</a><a className="text-link" href={linkedin} target="_blank" rel="noopener noreferrer"><LinkIcon light={linkedinLight.url} accent={linkedinAccent.url} />LinkedIn <ArrowUpRight /></a></div></div><div className="footer-bottom"><span>© 2026 Anayo Richard</span><span>Portals. Systems. Automations.</span></div></footer>
    <a className="wa-float" href={whatsapp} target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp"><img src={whatsappTile.url} alt="" width={56} height={56} /></a>
    <div className="mobile-book-bar"><a href={bookingUrl('mobile-bar')} target="_blank" rel="noopener noreferrer">Book a free call <ArrowUpRight /></a></div>
  </div>;
}
